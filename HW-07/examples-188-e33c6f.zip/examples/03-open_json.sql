-- ----------------------
-- OPENJSON
-- ----------------------
-- Этот пример запустить сразу весь по [F5]
-- (предварительно проверив ниже путь к файлу 03-open_json.json)

DECLARE @json nvarchar(max)

SELECT @json = BulkColumn
FROM OPENROWSET
(BULK 'Z:\2021-12-Evraz\08-xml_json_hw\examples\03-open_json.json', 
 SINGLE_CLOB)
as data 

-- Проверяем, что в @json
SELECT @json as [@json]

-- OPENJSON Явное описание структуры
SELECT *
FROM OPENJSON (@json, '$.Suppliers')
WITH (
    Id	        int,
    Supplier    nvarchar(100)   '$.SupplierInfo.Name',    
    Contact     nvarchar(max)   '$.Contact' AS JSON,
    City        nvarchar(100)   '$.CityName'
)




-- OPENJSON Без структуры

SELECT * FROM OPENJSON(@json)

SELECT * FROM OPENJSON(@json, '$.Suppliers')

-- Type:
--    0 = null
--    1 = string
--    2 = int
--    3 = bool
--    4 = array
--    5 = object